try:
	from setuptools import setup
except ImportError:
	from distutils.core import setup

config = {
	'description': 'Python skelet',
	'author': 'Laura Burticioaia',
	'author_email': 'laura.burticioaia@yahoo.com',
	'version': '0.1',
	'name': 'Python Project'
}

setup(
	scripts=['bin/scapy_task.py']
)	
